open LIST,"google.csv";
my %list = [];
while(<LIST>){
	chomp $_;
	my @temp = split(",",$_);
	$list{$temp[0]}++;
}
close LIST;

open IN,"drugFeatureP.csv";
my $header = <IN>;
chomp $header;

open TRAIN,">toTrain.csv";
open TEST,">toTest.csv";

print TRAIN $header,"\n";
print TEST $header,"\n";

while(<IN>){
	chomp $_;
	my @temp = split(",",$_);
	my $this_index = $temp[0];
	if($list{$this_index}){ print TRAIN $_,"\n" }
	else{ print TEST $_,"\n" }
}

close IN;
close TRAIN;
close TEST;